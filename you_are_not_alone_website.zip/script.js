
function newQuote() {
    const quotes = [
        "Your feelings are valid",
        "You are enough",
        "Don’t be so hard on yourself",
        "It’s okay to reach out for help",
        "Fill your mind with mindfulness"
    ];
    const quoteBox = document.getElementById("quote");
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    quoteBox.textContent = randomQuote;
}
